package com.example.oxquiz.repository;

import com.example.oxquiz.entity.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuizRepository extends JpaRepository<Quiz, Long> {

    @Query(value = "select * from quiz order by rand() limit 1" , nativeQuery = true)
    Quiz quizContent();

}
