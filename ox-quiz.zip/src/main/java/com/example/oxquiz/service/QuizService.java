package com.example.oxquiz.service;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.Quiz;
import com.example.oxquiz.repository.QuizRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class QuizService {
    private final QuizRepository quizRepository;

    public QuizService(QuizRepository quizRepository) {
        this.quizRepository = quizRepository;
    }

    public List<QuizDto> showAllQuiz() {
        List<QuizDto> quizDtoList = new ArrayList<>();
        return quizRepository.findAll()
                .stream()
                .map(x -> QuizDto.fromQuizEntity(x))
                .toList();
    }

    public void insertQuiz(QuizDto dto) {
        Quiz quiz = dto.fromQuizDto(dto);
        quizRepository.save(quiz);
    }

    public QuizDto getOneQuiz(Long id) {
        return quizRepository.findById(id)
                .map(x -> QuizDto.fromQuizEntity(x))
                .orElse(null);
    }

    public void update(QuizDto dto) {
        Quiz quiz = dto.fromQuizDto(dto);
        quizRepository.save(quiz);
    }

    public void delete(Long id) {
        quizRepository.deleteById(id);
    }

    public String getRandomQuiz() {
        return quizRepository.quizContent();
    }
}
