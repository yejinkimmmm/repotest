package com.example.oxquiz.dto;

import com.example.oxquiz.entity.Quiz;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class QuizDto {

    private Long id;

    @NotBlank(message = "공백일 수 없습니다")
    private String content;

    private String answer;

    @Size(min = 2, message = "이름은 2자 이상으로 입력해야 합니다.")
    private String name;


    public static QuizDto fromQuizEntity(Quiz quiz) {
        return new QuizDto(
                quiz.getId(),
                quiz.getContent(),
                quiz.getAnswer(),
                quiz.getName()
        );
    }

    public Quiz fromQuizDto(QuizDto dto) {
        Quiz quiz = new Quiz();
        quiz.setId(dto.getId());
        quiz.setContent(dto.getContent());
        quiz.setAnswer(dto.getAnswer());
        quiz.setName(dto.getName());

        return quiz;
    }
}
