package com.example.oxquiz.controller;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.Quiz;
import com.example.oxquiz.repository.QuizRepository;
import com.example.oxquiz.service.QuizService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Slf4j
@RequestMapping("quiz")

public class QuizController {
    private final QuizService quizService;

    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }



    @GetMapping("/quiz")
    public String quizAll(Model model) {
        List<QuizDto> quizDtoList = quizService.showAllQuiz();
        model.addAttribute("quizDto" , quizDtoList);
        return "showQuiz";
    }

    @GetMapping("insert")
    public String insertForm(Model model) {
        model.addAttribute("quizDto" , new QuizDto());
        return "insert";
    }

    @PostMapping("insert")
    public String insertAnswer(@Valid @ModelAttribute("quizDto") QuizDto dto , BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            log.info("Validation Error");
            return "insert";
        }
        quizService.insertQuiz(dto);
        log.info(dto.toString());

        return "redirect:/quiz/quiz";
    }
    @GetMapping("/update/{updateId}")
    public String updateQuiz(@PathVariable("updateId")Long id , Model model) {
        QuizDto quizDto = quizService.getOneQuiz(id);
        model.addAttribute("quizDto" , quizDto);
        return "update";
    }

    @PostMapping("update")
    public String update(@Valid @ModelAttribute("quizDto") QuizDto dto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            log.info("Validation Error");
            return "update";
        }
        quizService.update(dto);

        return "redirect:/quiz/quiz";
    }
    @PostMapping("/delete")
    public String delete(@RequestParam("delete") Long id) {
        quizService.delete(id);

        return "redirect:/quiz/quiz";
    }
    @GetMapping("/play")
    public String play(Model model){
        String quiz = quizService.getRandomQuiz();
        model.addAttribute("quiz", quiz);
        return "/play";
    }
}
