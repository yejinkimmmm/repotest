package com.example.basiccrud.dto;

import com.example.basiccrud.entity.Member;
import lombok.*;

@AllArgsConstructor // 자동으로 생성자를 만들어줌
@NoArgsConstructor // 인자가 하나도 없는 생성자
@ToString
@Data
public class MemberDto {
    private Long id;
    private String name;
    private int age;
    private String myAddress;

    public static MemberDto fromMemberEntity(Member member) {
        return new MemberDto(
                member.getId(),
                member.getName(),
                member.getAge(),
                member.getMyAddress()
        );
    }
}
