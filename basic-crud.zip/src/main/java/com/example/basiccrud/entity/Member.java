package com.example.basiccrud.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

@Entity //데이터베이스 테이블과 1:1로 관계가 있는 클래스
//@Table (name="member")
@Data
@ToString
public class Member {
    @Id //primary key
    @Column (name="id")
    @GeneratedValue (strategy = GenerationType.AUTO) // 자동증가
    private Long id;

    @Column (name="name", length = 40, nullable = false) //nullable = false --> 공백 허용 안함
    private String name;

    private int age;

    private String myAddress;
}
