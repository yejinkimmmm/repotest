package com.example.basiccrud.controller;

import com.example.basiccrud.dto.MemberDto;
import com.example.basiccrud.entity.Member;
import com.example.basiccrud.repository.MemberRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("member")
@Slf4j
public class MemberController {
//    생성자로 주입하기
    private final MemberRepository memberRepository;

    public MemberController(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }
//    @Autowired // 생성자로 받는 것과 같지만 위 코드로 씀
//    private MemberRepository memberRepository;

    @GetMapping("/view")
    public String showMember(Model model){
        // 전체 member 테이블 가져오기
//        List<Member> memberList = memberRepository.findAll(); // -> memberList
//        List<MemberDto> dtoList = new ArrayList<>(); // 위에서 받은 걸 dto 에 담아줌
//        for (Member member : memberList) {
//            dtoList.add(MemberDto.fromMemberEntity(member)); //  하나씩 읽어서 memberDto 에 들어감
//        }

        //스트림을 이용해서 처리하기
        List<MemberDto> dtoList = memberRepository
                .findAll()
                .stream()
                .map(x -> MemberDto.fromMemberEntity(x))
                .toList();

        log.info(dtoList.toString());
        //model 에 담아서 보내기
        model.addAttribute("title", "회원정보");
        model.addAttribute("dtoList", dtoList);
        return "showMember";
    }
    @GetMapping("/insert")
    public String insertFormView(Model model) {
        model.addAttribute("dto", new MemberDto());
        return "insertForm";
    }
}
