package com.example.schoolManager.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ReserveDTO {
    private Integer resv_no;
    private String name;
    private String host_name;
    private String host_addr;
    private String resv_date;
    private String resv_time;
    private String vacc_name;
    private String host_location;

    private int resv_count;
}
