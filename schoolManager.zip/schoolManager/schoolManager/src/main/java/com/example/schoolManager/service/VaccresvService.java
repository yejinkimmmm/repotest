package com.example.schoolManager.service;

import com.example.schoolManager.dto.VaccresvDTO;
import com.example.schoolManager.mapper.VaccineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VaccresvService {
    @Autowired
    VaccineMapper vaccineMapper;

    public void saveReserve(VaccresvDTO vaccresvDTO) {
        try {
            vaccineMapper.saveReserve(vaccresvDTO);
        } catch (Exception e) {
            // 예외 발생 시 로그를 출력하거나, 예외를 처리하는 코드를 추가하세요.
            e.printStackTrace(); // 예외를 콘솔에 출력합니다.
        }
    }

    public int getNewResvNo() {
        int maxResvNo = vaccineMapper.getMaxResvNo();
        return maxResvNo + 1;
    }
}
