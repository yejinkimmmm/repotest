package com.example.schoolManager.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.util.Date;

@Getter
@Setter
@ToString
public class VaccresvDTO {
    private Integer resvNo;
    private String jumin;
    private String hostCode;
    private String resvDate;
    private String resvTime;
    private String vCode;

}
