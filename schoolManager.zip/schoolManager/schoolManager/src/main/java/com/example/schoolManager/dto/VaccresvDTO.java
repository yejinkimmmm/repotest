package com.example.schoolManager.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class VaccresvDTO {
    private Integer resv_no;

    @NotBlank(message = "주민번호는 필수입니다.")
    private String jumin;

    @NotBlank(message = "병원 코드는 필수입니다.")
    private String host_code;

    @NotBlank(message = "예약 날짜는 필수입니다.")
    private String resv_date;

    @NotBlank(message = "예약 시간은 필수입니다.")
    private String resv_time;

    @NotBlank(message = "백신 코드는 필수입니다.")
    private String v_code;
}
