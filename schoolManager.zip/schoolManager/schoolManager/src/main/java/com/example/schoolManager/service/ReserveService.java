package com.example.schoolManager.service;

import com.example.schoolManager.dto.ReserveDTO;
import com.example.schoolManager.mapper.VaccineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReserveService {
    @Autowired
    VaccineMapper vaccineMapper;

    public List<ReserveDTO> getHostCount() {
        return vaccineMapper.resvCount();
    }

    public List<ReserveDTO> searchNo(Integer resv_no) {
        return vaccineMapper.getNo(resv_no);
    }
}
