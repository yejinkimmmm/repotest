package com.example.schoolManager.controller;

import com.example.schoolManager.dto.HospitalDTO;
import com.example.schoolManager.dto.VaccresvDTO;
import com.example.schoolManager.service.HospitalService;
import com.example.schoolManager.service.JuminService;
import com.example.schoolManager.service.VaccresvService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class VaccineController {
    @Autowired
    VaccresvService vaccresvService;
    @Autowired
    HospitalService hospitalService;
    @Autowired
    JuminService juminService;

    @GetMapping("/")
    public String home() {
        return "/index";
    }

    @GetMapping("/reserve")
    public String showReserve(Model model) {
        List<HospitalDTO> hospital = hospitalService.getAllHospital();
        model.addAttribute("host", hospital);
        model.addAttribute("vaccresvDTO", new VaccresvDTO());
        return "reserve";
    }

    @PostMapping("/reserve")
    public String saveReserve(@Valid @ModelAttribute("vaccresvDTO") VaccresvDTO vaccresvDTO, BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<HospitalDTO> hospital = hospitalService.getAllHospital();
            model.addAttribute("host", hospital);
            return "reserve";
        }
        vaccresvService.saveReserve(vaccresvDTO);
        return "redirect:/";
    }

    @PostMapping("/search")
    public String search(@RequestParam("jumin") String jumin, Model model) {
        List<VaccresvDTO> vaccresvDTO = vaccresvService.searchJumin(jumin);
        // 예약 정보가 없는 경우
        if(vaccresvDTO.isEmpty()) {
            // 메시지와 함께 입력한 주민번호를 모델에 추가
            model.addAttribute("jumin", jumin);
            return "noFound"; // 예약 정보가 없는 경우를 나타내는 뷰로 이동
        }

        // 예약 정보가 있는 경우, 주민번호와 예약 정보를 모델에 추가하여 결과를 표시
        model.addAttribute("jumin", jumin);
        model.addAttribute("result", vaccresvDTO);
        return "result";
    }

    @GetMapping("/search")
    public String result() {
        return "search";
    }

    @GetMapping("/situation")
    public String situation(Model model) {
        List<HospitalDTO> hospitalList = hospitalService.getHostCount();

        int totalCount = hospitalList.stream()
                .mapToInt(HospitalDTO::getResvCount)
                .sum();

        model.addAttribute("hospital", hospitalList);
        model.addAttribute("total", totalCount);
        return "situation";
    }
}
