package com.example.schoolManager.controller;

import com.example.schoolManager.dto.HospitalDTO;
import com.example.schoolManager.dto.ReserveDTO;
import com.example.schoolManager.dto.VaccresvDTO;
import com.example.schoolManager.service.HospitalService;
import com.example.schoolManager.service.ReserveService;
import com.example.schoolManager.service.VaccresvService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class VaccineController {
    @Autowired
    VaccresvService vaccresvService;
    @Autowired
    HospitalService hospitalService;
    @Autowired
    ReserveService reserveService;

    @GetMapping("/")
    public String home() {
        return "/index";
    }

    @GetMapping("/reserve")
    public String showReserve(Model model) {
        List<HospitalDTO> hospital = hospitalService.getAllHospital();

        int newResvNo = vaccresvService.getNewResvNo();
        VaccresvDTO vaccresvDTO = new VaccresvDTO();
        vaccresvDTO.setResv_no(newResvNo);

        model.addAttribute("host", hospital);
        model.addAttribute("vaccresvDTO", vaccresvDTO);
        return "reserve";
    }

    @PostMapping("/reserve")
    public String saveReserve(@Valid @ModelAttribute("vaccresvDTO") VaccresvDTO vaccresvDTO, BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<HospitalDTO> hospital = hospitalService.getAllHospital();
            model.addAttribute("host", hospital);
            return "reserve";
        }
        vaccresvService.saveReserve(vaccresvDTO);
        return "redirect:/";
    }
    @PostMapping("/search")
    public String search(@RequestParam("resv_no") Integer resv_no, Model model) {
        model.addAttribute("resvNo", resv_no); // 입력한 예약 번호를 모델에 추가
        List<ReserveDTO> reserveDTOList = reserveService.searchNo(resv_no);
        // 예약 정보가 없는 경우
        if (reserveDTOList.isEmpty()) {
            return "noFound"; // 예약 정보가 없는 경우를 나타내는 뷰로 이동
        }

        // 예약 정보가 있는 경우, 예약 정보를 모델에 추가하여 결과를 표시
        model.addAttribute("result", reserveDTOList);
        return "result";
    }

    @GetMapping("/search")
    public String result() {
        return "search";
    }

    @GetMapping("/situation")
    public String situation(Model model) {
        List<ReserveDTO> reserveDTO = reserveService.getHostCount();

        int totalCount = reserveDTO.stream()
                .mapToInt(ReserveDTO::getResv_count)
                .sum();

        model.addAttribute("hospital", reserveDTO);
        model.addAttribute("total", totalCount);
        return "situation";
    }
}
