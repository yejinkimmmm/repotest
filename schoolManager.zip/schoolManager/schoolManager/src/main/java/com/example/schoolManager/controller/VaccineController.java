package com.example.schoolManager.controller;

import com.example.schoolManager.dto.HospitalDTO;
import com.example.schoolManager.dto.VaccresvDTO;
import com.example.schoolManager.service.HospitalService;
import com.example.schoolManager.service.VaccresvService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class VaccineController {
    @Autowired
    VaccresvService vaccresvService;
    @Autowired
    HospitalService hospitalService;

    @GetMapping("/")
    public String home() {
        return "/index";
    }

    @GetMapping("/reserve")
    public String showReserve(Model model) {
        List<HospitalDTO> hospital = hospitalService.getAllHospital();
        model.addAttribute("host", hospital);
        model.addAttribute("vaccresvDTO", new VaccresvDTO());
        return "reserve";
    }

    @PostMapping("/reserve")
    public String saveReserve(@Valid @ModelAttribute("vaccresvDTO") VaccresvDTO vaccresvDTO, BindingResult result, Model model) {
        if (result.hasErrors()) {
            List<HospitalDTO> hospital = hospitalService.getAllHospital();
            model.addAttribute("host", hospital);
            return "reserve";
        }
        vaccresvService.saveReserve(vaccresvDTO);
        return "redirect:/";
    }
}
