package com.example.schoolManager.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HospitalDTO {
    @NotBlank(message = "병원 코드는 필수입니다.")
    private String host_code;

    @NotBlank(message = "병원 이름은 필수입니다.")
    private String host_name;

    private String hostTel;
    private String hostAddr;
    
    private int resvCount;

}
