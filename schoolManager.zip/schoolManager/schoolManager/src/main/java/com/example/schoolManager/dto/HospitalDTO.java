package com.example.schoolManager.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HospitalDTO {
    private String hostCode;
    private String hostName;
    private String hostTel;
    private String hostAddr;
}
