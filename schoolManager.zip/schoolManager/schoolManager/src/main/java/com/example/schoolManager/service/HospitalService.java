package com.example.schoolManager.service;

import com.example.schoolManager.dto.HospitalDTO;
import com.example.schoolManager.mapper.VaccineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HospitalService {
    @Autowired
    VaccineMapper vaccineMapper;
    public List<HospitalDTO> getAllHospital() {
        return vaccineMapper.getAllHospital();
    }
}
