package com.example.schoolManager.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface VaccineMapper {
}
