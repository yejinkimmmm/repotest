package com.example.schoolManager.mapper;

import com.example.schoolManager.dto.HospitalDTO;
import com.example.schoolManager.dto.ReserveDTO;
import com.example.schoolManager.dto.VaccresvDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface VaccineMapper {

    void saveReserve(@Param("vaccresvDTO") VaccresvDTO vaccresvDTO);
    List<HospitalDTO> getAllHospital();

    List<ReserveDTO> getNo(Integer resv_no);

    List<ReserveDTO> resvCount();

    int getMaxResvNo();

}
