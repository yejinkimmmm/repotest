package com.example.schoolManager.service;

import org.springframework.stereotype.Service;

@Service
public class HospitalService {
}
