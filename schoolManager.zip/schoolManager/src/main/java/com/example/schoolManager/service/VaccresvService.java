package com.example.schoolManager.service;

import com.example.schoolManager.dto.VaccresvDTO;
import com.example.schoolManager.mapper.VaccineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VaccresvService {
    @Autowired
    VaccineMapper vaccineMapper;
    public void saveResv(VaccresvDTO vaccresvDTO) {
        vaccineMapper.saveResv(vaccresvDTO);
    }
}
