package com.example.schoolManager.controller;

import com.example.schoolManager.dto.VaccresvDTO;
import com.example.schoolManager.service.VaccresvService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class VaccineController {
    @Autowired
    VaccresvService vaccresvService;

    @GetMapping("/")
    public String home() {
        return "/index";
    }

    @GetMapping("/resv")
    public String resvView() {
        return "/resv";
    }

    @PostMapping("/resv")
    public String resv(VaccresvDTO vaccresvDTO) {
        vaccresvService.saveResv(vaccresvDTO);
        System.out.println(vaccresvDTO);
        return "redirect:/";
    }
}
