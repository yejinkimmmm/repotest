package com.example.schoolManager.mapper;

import com.example.schoolManager.dto.VaccresvDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface VaccineMapper {
    void saveResv(@Param("vaccresvDTO") VaccresvDTO vaccresvDTO);
}
