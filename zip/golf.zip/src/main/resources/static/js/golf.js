function updateMemberId() {
    var select = document.getElementById("memberSelect");
    var memberIdNo = document.getElementById("memberIdNo");
    memberIdNo.value = select.value;
}
function updateClassName() {
    var select = document.getElementById("classSelect");
    var priceSelect = document.getElementById("priceSelect")
    var selectedValue = parseInt(classSelect.value); // 선택된 강의명(teacherCode)

        // teacherCode 와 수강료 매핑
        var feeMap = {
            100: 100000,
            200: 200000,
            300: 300000,
            400: 400000
        };

        var fee = feeMap[selectedValue]; // 선택된 강의명에 따른 수강료

        if (fee !== undefined) {
            priceSelect.value = fee; // 수강료 업데이트
        } else {
            priceSelect.value = ""; // 값이 없을 때 초기화
        }

       var memberId = parseInt(memberIdNo.value); // 문자열을 정수로 변환
           if (!isNaN(memberId) && memberId >= 20000) { // && -> 하나라도 거짓이면 거짓 memberId가 숫자이고,20000 이상인지 검사
               var discount = fee / 2; // 수강료 절반으로 나누기
               priceSelect.value = discount; // 할인된 수강료로 업데이트
           }
}
// 허용된 강의장소 목록
const allowedClassAreas = ["서울본원", "성남분원", "대전분원", "부산분원", "대구분원"];

// 강의장소 유효성 검사
function validateClassArea() {
    const classAreaInput = document.getElementById("area");
    const errorMessage = document.getElementById("errorMessage");

    const value = classAreaInput.value.trim();

    if (allowedClassAreas.includes(value)) {
        errorMessage.textContent = ""; // 오류 메시지 제거
        return true;
    } else {
        errorMessage.textContent = "강의장소는 [서울본원], [성남분원], [대전분원], [부산분원], [대구분원]만 가능합니다."; // 오류 메시지
        return false;
    }
}

// 폼 제출 전 유효성 검사
function checkBeforeSubmit(event) {
    if (document.getElementById("month").value.trim().length == 0) { // 수강월 유효성 검사
        alert("수강월을 입력해주세요.");
        event.preventDefault(); // 폼 제출 중단
        return false;
    }

    if (!validateClassArea()) { // 강의장소 유효성 검사
        event.preventDefault(); // 폼 제출 중단
        return false;
    }

    alert("입력이 완료되었습니다.");
    return true; // 유효성 검사 성공
}

// 폼 초기화
function reset() {
    alert("모든 정보를 지우고 처음부터 다시 시작합니다🌞");
    document.getElementById("frm").reset(); // 폼 초기화
    document.getElementById("month").focus(); // 초기 포커스
}
