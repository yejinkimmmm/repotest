package com.example.golf.service;

import com.example.golf.repository.MemberRepository;
import org.springframework.stereotype.Service;

@Service
public class MemberService {
}
