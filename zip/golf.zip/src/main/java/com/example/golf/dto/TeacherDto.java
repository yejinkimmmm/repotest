package com.example.golf.dto;

import com.example.golf.entity.Class;
import com.example.golf.entity.Teacher;
import jakarta.persistence.Column;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TeacherDto {

    public String teacherCode;
    public String teacherName;
    public String className;
    public int price;
    public String teacherRegisterDate;

    // 포맷팅된 수강료, 날짜
    public String formatPrice;
    public String formatDate;

    public TeacherDto(String teacherCode, String teacherName, String className, int price, String teacherRegisterDate) {
        this.teacherCode = teacherCode;
        this.teacherName = teacherName;
        this.className = className;
        this.price = price;
        this.teacherRegisterDate = teacherRegisterDate;
    }

    public static TeacherDto fromTeacherEntity(Teacher teacher) {
        return new TeacherDto(
                teacher.getTeacherCode(),
                teacher.getTeacherName(),
                teacher.getClassName(),
                teacher.getPrice(),
                teacher.getTeacherRegisterDate()
        );
    }

    public void setFormatPrice(String formatPrice) {
        this.formatPrice = formatPrice;
    }

    public void setFormatDate(String formatDate) {
        this.formatDate = formatDate;
    }

}
