package com.example.oxquiz.controller;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.Quiz;
import com.example.oxquiz.repository.QuizRepository;
import com.example.oxquiz.service.QuizService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@Slf4j
@RequestMapping("quiz")

public class QuizController {
    private final QuizService quizService;
    private final QuizRepository quizRepository;

    public QuizController(QuizService quizService, QuizRepository quizRepository) {
        this.quizService = quizService;
        this.quizRepository = quizRepository;
    }



    @GetMapping("/quiz")
    public String quizAll(Model model) {
        List<QuizDto> quizDtoList = quizService.showAllQuiz();
        model.addAttribute("quizDto" , quizDtoList);
        return "showQuiz";
    }

    @GetMapping("insert")
    public String insertForm(Model model) {
        model.addAttribute("quizDto" , new QuizDto());
        return "insert";
    }

    @PostMapping("insert")
    public String insertAnswer(@Valid @ModelAttribute("quizDto") QuizDto dto , BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            log.info("Validation Error");
            return "insert";
        }
        quizService.insertQuiz(dto);
        log.info(dto.toString());

        return "redirect:/quiz/quiz";
    }
    @GetMapping("/update/{updateId}")
    public String updateQuiz(@PathVariable("updateId")Long id , Model model) {
        QuizDto quizDto = quizService.getOneQuiz(id);
        model.addAttribute("quizDto" , quizDto);
        return "update";
    }

    @PostMapping("update")
    public String update(@Valid @ModelAttribute("quizDto") QuizDto dto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            log.info("Validation Error");
            return "update";
        }
        quizService.update(dto);

        return "redirect:/quiz/quiz";
    }
    @PostMapping("/delete")
    public String delete(@RequestParam("delete") Long id) {
        quizService.delete(id);

        return "redirect:/quiz/quiz";
    }
    @GetMapping("/play")
    public String play(Model model){
        Quiz quiz = quizService.getRandomQuiz();
        model.addAttribute("quizContent", quiz.getContent());
        model.addAttribute("quizAnswer", quiz.getAnswer());
        return "/play";
    }
    @PostMapping("/check")
    public String checkAnswer(@RequestParam("correctAnswer") String correctAnswer,
                              @RequestParam("quizAnswer") String quizAnswer,
                              Model model) {

//        String answer = (String) model.getAttribute("quizAnswer");


        if (correctAnswer.equals(quizAnswer)) {
            model.addAttribute("message", "정답입니다!");
        } else {
            model.addAttribute("message", "정답이 아닙니다");
        }
        return "/check";
    }
}
