package kr.co.zinn.jspTest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CarController {
	@GetMapping("/car/step1")
	public String car_test_01() {
		return "/jsp-test/step1";
	}
	
	@GetMapping("/step1-if")
	public String step_01() {
		return "/jsp-test/step1-if";
	}
	
	@GetMapping("/step2-if")
	public String step_02(Model model) {
		Person dto = new Person("손흥민" , 31);
		model.addAttribute("dto", dto);
		return "/jsp-test/step2-choose";
	}
}
