package kr.co.zinn.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import kr.co.zinn.dto.AdminDto;

@Mapper
public interface AdminMapper {

	int adminInsert(@Param("adminDto")AdminDto adminDto);

	AdminDto loginConfirm(@Param("adminDto") AdminDto adminDto);

	List<AdminDto> adminList();

	int approvalView(String a_id);

	void update(AdminDto adminDto);

	List<AdminDto> searchAdmin(@Param("category") String category, @Param("keyword") String keyword);
}
