package com.example.pcRoom.service;

import com.example.pcRoom.dto.BestSellerDto;
import com.example.pcRoom.dto.MenuDto;
import com.example.pcRoom.dto.SellDto;
import com.example.pcRoom.dto.UsersDto;
import com.example.pcRoom.entity.Menu;
import com.example.pcRoom.entity.Sell;
import com.example.pcRoom.entity.Users;
import com.example.pcRoom.repository.MenuRepository;
import com.example.pcRoom.repository.SellRepository;
import com.example.pcRoom.repository.UsersRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminService {
    private final SellRepository sellRepository;
    private final MenuRepository menuRepository;
    private final UsersRepository usersRepository;

    public AdminService(SellRepository sellRepository, MenuRepository menuRepository, UsersRepository usersRepository) {
        this.sellRepository = sellRepository;
        this.menuRepository = menuRepository;
        this.usersRepository = usersRepository;
    }

    public List<SellDto> sell(Page<Sell> paging) {
        List<SellDto> sellDtoList = new ArrayList<>();

        for (Sell s : paging.getContent()) {
            Menu menu = menuRepository.findById(s.getMenuId()).orElse(null);
            Users users = usersRepository.findById(s.getUserId()).orElse(null);

            MenuDto menuDto = MenuDto.fromMenuEntity(menu);
            UsersDto usersDto = UsersDto.fromUserEntity(users);

            int sellAmount = s.getSellAmount();
            sellDtoList.add(SellDto.fromSellEntity(s, menuDto, usersDto, sellAmount));
        }
        return sellDtoList;
    } // 주문 현황


    public List<SellDto> total() {
        List<SellDto> sellDtos =  new ArrayList<>();

        int total = sellRepository.total();
        sellDtos.add(SellDto.fromtotal(total));
        return sellDtos;
    } // 총 매출


    public Page<Sell> pagingList(Pageable pageable) {
        return sellRepository.findAll(pageable);
    } // 페이징된 데이터 반환
    

    public void minusSellAmountToMenuAmount(Long menuId , int sellAmount){
        Menu menu = menuRepository.findById(menuId).orElse(null);
        int menuAmount = menu.getMenuAmount();
        menuAmount = menuAmount - sellAmount;
        menu.setMenuAmount(menuAmount);
        menuRepository.save(menu);
    }//주문한 수량에 맞게 재고가 줄어들게 //sellAmount 주문한 수량 , menuAmount 재고 (주문한 수량 > 재고 일때 구현해야함 미완)

    public List<BestSellerDto> sales() {
        List<BestSellerDto> sell = sellRepository.sellList();


        for (BestSellerDto sellDto : sell) {
            System.out.println(sellDto);
        }
        return sell;
    }
}

//int count = sellRepository.sellCount();
//String name = sellRepository.sellName();
//        sellDtoList.add(SellDto.sellNameAndCount(count,name));