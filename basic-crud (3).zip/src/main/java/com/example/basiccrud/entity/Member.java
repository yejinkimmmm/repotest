package com.example.basiccrud.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Member {
    @Id // primary key
    @GeneratedValue(strategy = GenerationType.AUTO) // 자동증가
    private Long id;

    @Column(length = 20 , nullable = false) // 이름의 길이=20, null 값 허용 안함
    private String name;

    private int age;

    @Column(name = "address" , length = 100)
    private String addr;
}
