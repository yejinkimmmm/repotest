package kr.co.aaa.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
public class ConsultDto {
	
	public ConsultDto getConsultDto() {
        return this;
    }
   
	
	private Long cust_sn; // 고객 일련번호
	private String cust_nm; // 고객 이름
	private String eml_addr; // 이메일주소
	private String brdt; // 생년월일
	private String home_telno; // 자택전화번호
	private String mbl_telno; // 휴대전화번호
	private String pridtf_no; // 개인식별번호 (주민번호)
	private String cr_nm; // 직업명
	private String road_nm_addr; // 도로명 주소
	private String pic_sn_vl; // 담당자 일련번호
	private String tkcg_dept_nm; // 담당 부서명
	private String frst_reg_dt; // 최초 등록일
	private BigDecimal frst_rgtr_sn; // 최초 등록자 일련번호
	private String last_mdfcn_dt; // 마지막 수정일
	private String use_yn; // 사용 여부 (삭제 회원인지(Y) 아닌지(N))

}
