package kr.co.kdt.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class kdt_cust_info_basc_dto {
	private int cust_sn;
	private String cust_nm;
	private String eml_addr;
	private String brdt;
	private String home_telno;
	private String mbl_telno;
	private String pridtf_no;
	private String cr_nm;
	private String road_nm_addr;
	private String pic_sn_vl;
	private String tkcg_dept_nm;
	private String frst_reg_dt;
	private int frst_rgtr_sn;
	private String last_mdfcn_dt;
	private char use_yn;

}
