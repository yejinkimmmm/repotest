package com.myboard.repository;

import com.myboard.entity.Users;
import groovy.util.logging.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@Transactional
@TestPropertySource(locations="classpath:application-test.properties")
@Slf4j
class UsersRepositoryTest {
    private static final Logger log = LoggerFactory.getLogger(UsersRepositoryTest.class);
    @Autowired
    UsersRepository usersRepository;
    @Test
    void test(){
        Long cnt = usersRepository.findAll().stream().count();
        System.out.println("-----------------" + cnt);
    }

    @Test
    @DisplayName("findByName 메소드 테스트")
    void findByNameTest(){
        String name = "Micky";
        //메소드 레퍼런스
        //Java 8에서 도입된 메소드 레퍼런스(Method Reference)는 Lambda 표현식을
        // 더 간단하게 표현하는 방법
        usersRepository.findByName(name).forEach(x -> log.info(String.valueOf(x)));

        //람다식
        usersRepository.findByName("Lola").forEach(x-> System.out.println(x));
    }
}