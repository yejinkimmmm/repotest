package com.myboard.dto;

public enum Gender {
    Male,
    Female
}
