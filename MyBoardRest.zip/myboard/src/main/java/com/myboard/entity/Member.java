package com.myboard.entity;

import com.myboard.dto.Gender;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Member {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "nickname")
    private String nickName;
    private String email;

    @Enumerated(EnumType.STRING)
    private Gender gender;
    @Column(name = "inserted_at", updatable = false)
    LocalDateTime insertedAt;
    @Column(name = "updated_at", insertable = false)
    LocalDateTime updatedAt;
}
