package com.myboard.api;

import com.myboard.dto.CommentDto;
import com.myboard.service.CommentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class CommentApiController {
    @Autowired
    CommentService commentService;
    // 1. 댓글 조회

    // 2. 댓글 생성
    @PostMapping("/api/articles/{articleId}/comments")
    public CommentDto create(@PathVariable Long articleId,
                             @RequestBody CommentDto dto) {
        // 서비스 처리
        CommentDto createdDto = commentService.create(articleId, dto);

        return createdDto;
    }

    // 3. 댓글 수정
    @PatchMapping("/api/comments/{id}")
    public CommentDto update(@PathVariable Long id,
                             @RequestBody CommentDto dto) {
        log.info(dto.toString());
        // 서비스에서 처리
        CommentDto updateDto = commentService.update(id, dto);
        // 결과 응답

        return updateDto;
    }

    // 4. 댓글 삭제
    @DeleteMapping("/api/comments/{id}")
    public CommentDto delete(@PathVariable Long id) {
        // 서비스 호출
        CommentDto deletedDto = commentService.delete(id);

        return deletedDto;
    }
}
