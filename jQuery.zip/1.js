$(function() { // 익명 함수 
  $("h2").click(function() {
    $("h2").hide();
  });
});