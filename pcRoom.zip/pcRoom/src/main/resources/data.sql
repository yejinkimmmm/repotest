insert into users(user_id,name,password,money,status) values ("ozllzlu" , "김예진" , "7777" , 10000 ,"관리자")
insert into users(user_id,name,password,money,status) values ("ozllzlu2" , "김예지" , "7777" , 10000 ,"손님")
insert into menu(menu_id,menu_name,menu_amount,menu_price) values (1,"신라면",10,1000)
insert into menu(menu_id,menu_name,menu_amount,menu_price) values (2,"불닭볶음면",10,2000)