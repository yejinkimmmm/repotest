package com.example.pcRoom.dto;

import com.example.pcRoom.entity.OrderForm;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.security.core.parameters.P;

@Data
@AllArgsConstructor
public class OrderDto {

    private Long id;
    private String userId;
    private int menuId;
    private int orderAmount;

    private MenuDto menuDto;
    private UsersDto usersDto;

    public static OrderDto fromOrderEntity(OrderForm form,MenuDto menuDto, UsersDto usersDto) {
        return new OrderDto(
                form.getId(),
                form.getUserId(),
                form.getMenuId(),
                form.getOrderAmount(),
                menuDto,
                usersDto
        );

    }

}
