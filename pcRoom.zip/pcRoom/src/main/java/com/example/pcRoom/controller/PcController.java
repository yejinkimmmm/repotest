package com.example.pcRoom.controller;

import com.example.pcRoom.dto.OrderDto;
import com.example.pcRoom.service.AdminService;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class PcController {
    private final AdminService adminService;

    public PcController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/main/order_from")
    public String orderForm(Model model) {
        List<OrderDto> orderDtoList = adminService.orderForm();
        model.addAttribute("orderDto", orderDtoList);
        return null; // 아직 페이지를 안 만들었음
    }
}
