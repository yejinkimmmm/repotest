package com.example.pcRoom.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
}
