package com.example.pcRoom.service;

import com.example.pcRoom.dto.MenuDto;
import com.example.pcRoom.dto.OrderDto;
import com.example.pcRoom.dto.UsersDto;
import com.example.pcRoom.entity.Menu;
import com.example.pcRoom.entity.OrderForm;
import com.example.pcRoom.entity.Users;
import com.example.pcRoom.repository.MenuRepository;
import com.example.pcRoom.repository.OrderRepository;
import com.example.pcRoom.repository.UsersRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AdminService {
    private final OrderRepository orderRepository;
    private final MenuRepository menuRepository;
    private final UsersRepository usersRepository;

    public AdminService(OrderRepository orderRepository, MenuRepository menuRepository, UsersRepository usersRepository) {
        this.orderRepository = orderRepository;
        this.menuRepository = menuRepository;
        this.usersRepository = usersRepository;
    }

    public List<OrderDto> orderForm() {
        List<OrderForm> orderForms = orderRepository.findAll(); // 모든 테이블 내용 가져오기
        List<OrderDto> orderDto = new ArrayList<>(); // 담아줄 빈 껍데기

        for (OrderForm form : orderForms) {
            Menu menu = menuRepository.findById(Long.valueOf(form.getMenuId())).orElse(null);
            // orderForm 의 MenuId 랑 Menu 테이블의 MenuId 가 같으니까
            Users users = usersRepository.findById(form.getUserId()).orElse(null);
            MenuDto menuDto = MenuDto.fromMenuEntity(menu); // Entity 에서 필요한 정보 dto 로 가져오기?
            UsersDto usersDto = UsersDto.fromUserEntity(users);
            orderDto.add(OrderDto.fromOrderEntity(form ,menuDto, usersDto)); // 다 추가 ~
        }
        return orderDto;
    } // order Table
      // id = 자동증가
      // menuId, UserId 끌어온 거 같음 -> 돌려보기
      // orderAmount 수량체크는
}
