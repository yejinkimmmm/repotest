insert into article(title, content) values ('가가가','111');
insert into article(title, content) values ('나나나','222');
insert into article(title, content) values ('다다다','333');