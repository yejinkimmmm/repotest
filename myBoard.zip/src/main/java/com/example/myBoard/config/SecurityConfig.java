package com.example.myBoard.config;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean // 콩이당! 뻥이고 -> 클래스 인스턴스
    public BCryptPasswordEncoder bCryptPasswordEncoder() { // 암호화
        return new BCryptPasswordEncoder();
    }
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests((request) -> request
                .requestMatchers("/css/**", "/js/**", "/images/**").permitAll()
                .requestMatchers("/users/**").permitAll()
//                .anyRequest().authenticated())// 이(위 폴더들) 외에 다른 것들은 인증 받아야 접근 가능 해
                .requestMatchers("/**").permitAll())

            .formLogin((form) -> form
                    .loginPage("/user/login")
                    .loginProcessingUrl("/login")
                    .defaultSuccessUrl("/"))
            .logout((out) -> out
                    .logoutSuccessUrl("/")
                    .logoutUrl("/logout")
        );
        return http.build();
    }
}
