package com.example.myBoard.config;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity // 웹 환경 관련
public class SecurityConfig {
    @Bean // 콩이당! 뻥이고 -> 클래스 인스턴스
    public BCryptPasswordEncoder bCryptPasswordEncoder() { // 암호화
        return new BCryptPasswordEncoder();
    }
    @Bean // 콩 심으면 스프링이 관리해줌
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests((request) -> request
                .requestMatchers("/css/**", "/js/**", "/images/**" ,"/error").permitAll()  // permitAll : 싹 다 승인 ~
                .requestMatchers("/user/**").permitAll()
                .anyRequest().authenticated()) // 이(위 폴더들) 외에 다른 것들은 인증 받아야 접근 가능 해
//                .requestMatchers("/**").permitAll()) // 모든 파일 접근 허용 / 막아두면 아무도 회원가입 못하니까

            .formLogin((form) -> form   // 내가 만들어 놓은 로그인 폼을 쓰겠다 !
                    .loginPage("/user/login")
                    .loginProcessingUrl("/login")
//                    .usernameParameter("email") email이 ID가 되는 코드
                    .defaultSuccessUrl("/articles/paging", true))

            .logout((out) -> out
                    .logoutSuccessUrl("/")
                    .logoutUrl("/logout")
//                    .csrf(csrf ->csrf.disable()
        );
        return http.build();
    }
}
