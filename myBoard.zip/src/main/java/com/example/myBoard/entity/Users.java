package com.example.myBoard.entity;

import com.example.myBoard.constant.Gender;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class Users {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;  // findById

    public String name; // findByName
    public String email;

    @Enumerated(EnumType.STRING)
    public Gender gender;

    @Column(name = "like_color")
    public String likeColor; // findByLikeColor


    @Column(name = "created_at", updatable = false) // updatable = false 업데이트 불가
    @CreatedDate
    public LocalDateTime createdAt; // findByCreatedAt

    @Column(name = "updated_at", insertable = false) // insertable = false
    @LastModifiedDate // 최종 수정 날짜 자동으로
    public LocalDateTime updatedAt; // findByUpdatedAt
}
