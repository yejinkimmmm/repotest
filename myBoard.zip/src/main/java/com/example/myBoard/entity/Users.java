package com.example.myBoard.entity;

import com.example.myBoard.constant.Gender;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Users {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    public String name;
    public String email;
    @Enumerated(EnumType.STRING)
    public Gender gender;
    @Column(name = "like_color")
    public String likeColor;
    @Column(name = "created_at")
    public LocalDateTime createdAt;
    @Column(name = "updated_at")
    public LocalDateTime updatedAt;
}
