package com.example.myBoard.repository;

import com.example.myBoard.constant.Gender;
import com.example.myBoard.entity.Users;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface UsersRepository extends JpaRepository<Users,Long> {
    //이름으로 검색
    List<Users> findByName(String name);

    // pink 색상 데이터 중 상위 3개 데이터만 가져오기
    List<Users> findTop3ByLikeColor(String likeColor);

    // gender 와 color 로 테이블 검색


    // 범위로 검색(After,Before) -- 날짜/시간 데이터에 한정
    List<Users> findByCreatedAtAfter(LocalDateTime searchDate);

    // IN 구문
    List<Users> findByLikeColorIn(List<String> likeColor);

    // 문자열 관련
    List<Users> findByNameStartingWith(String name);
    List<Users> findByNameEndingWith(String name);
    List<Users> findByNameContains(String name);
    List<Users> findByNameLike(String name);

    // Sort 별도 처리 하는 법
    // Orange 색상 검색해서 Gender 오름차순, CreatedAt 내림차순
    List<Users> findByLikeColor(String color, Sort sort);

    //페이징처리
    //주어진 아이디보다 큰 데이터를 내림차순으로 검색한 후 페이징처리
    //(id=200이상,5번째 페이지,한 페이지당 10개씩)
    Page<Users> findByIdGreaterThanEqualOrderByIdDesc(Long id, Pageable paging);

        // 범위로 검색 (Between)
    List<Users> findByCreatedAtBetween(LocalDateTime startDate, LocalDateTime endDate);
    List<Users> findByIdBetween(Long startId, Long endId);



    List<Users> findByGenderAndNameLikeOrGenderAndNameLike(Gender gender, String name, Gender gender2, String name2);
    List<Users> findByEmailLike(String eMail);
    List<Users> findByCreatedAtBetweenAndNameStartingWith(LocalDateTime startDate, LocalDateTime endDate, String name);
    List<Users> findTop10ByOrderByCreatedAtDesc();
    List<Users> findByGenderAndLikeColor(Gender gender, String likeColor);
    Page<Users> findByGenderOrderByIdDesc(Gender gender, Pageable paging);
    List<Users> findByEmailLikeAndGenderOrderByCreatedAtDesc(String email,Gender gender);

}
