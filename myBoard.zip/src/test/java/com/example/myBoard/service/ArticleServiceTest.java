package com.example.myBoard.service;

import com.example.myBoard.dto.ArticleDto;
import com.example.myBoard.entity.Article;
import jakarta.transaction.Transactional;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@Transactional
@TestPropertySource(locations = "classpath:application-test.properties")
class ArticleServiceTest {
    @Autowired
    ArticleService articleService;
    @Test
    @DisplayName("전체데이터_ 읽기")
    void showAll() {
        //Given
        int totalCount = 3;
        //When
        List<ArticleDto> lists = articleService.showAll();
        int actualCount = lists.size();
        //Then
        assertThat(actualCount).isEqualTo(totalCount);
    }
    @Test
    @DisplayName("자료입력_테스트")
    void insert() {
        //Given
        ArticleDto expectDto = ArticleDto.builder()
                .id(4L)
                .title("라라라")
                .content("444")
                .build();
        //When
        articleService.insert(new ArticleDto(null,"라라라","444"));
        //Then
        assertThat(articleService.findId(4L).getTitle()).isEqualTo("라라라");
        assertThat(articleService.findId(4L).getContent()).isEqualTo("444");
    }

    @Test
    @DisplayName("자료삭제_테스트")
    void delete() {
        //given
        // 1번 자료 삭제 후 null 인지 확인
        Long deleteId = 1L;
        //when
        articleService.delete(deleteId);
        //then
        ArticleDto article = articleService.findId(1L);
        assertThat(article).isEqualTo(null);
    }

    @Test
    @DisplayName("자료수정_테스트")
    void update() {
        //Given
        //1번 자료 수정(1,가가가,111) -> (1,타이틀,내용)
        ArticleDto expectDto = ArticleDto.builder()
                .id(1L)
                .title("타이틀")
                .content("내용")
                .build();
        //When
        articleService.update(new ArticleDto(1L,"타이틀","내용"));
        ArticleDto articleDto = articleService.findId(1L);
        //Then
        assertThat(articleDto.toString()).isEqualTo(expectDto.toString());
    }

    @Test
    @DisplayName("단건자료검색_테스트")
    void findId() {
        //Given
        ArticleDto expectDto = ArticleDto.builder()
                .id(2L)
                .title("나나나")
                .content("222")
                .build();
        //When
        ArticleDto actualDto = articleService.findId(2L);
        //Then
        assertThat(actualDto.toString()).isEqualTo(expectDto.toString());
    }
}