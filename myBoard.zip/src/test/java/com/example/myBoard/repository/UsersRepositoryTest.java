package com.example.myBoard.repository;

import com.example.myBoard.constant.Gender;
import com.example.myBoard.entity.Users;
import jakarta.transaction.Transactional;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.TestPropertySource;

import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
//@Transactional
@TestPropertySource(locations = "classpath:application-test.properties")
class UsersRepositoryTest {
    @Autowired
    UsersRepository usersRepository;
    @Test
    void findByName테스트() {
        String findName = "Hugo";
        usersRepository.findByName(findName).forEach(users -> System.out.println(users));
    }
    @Test
    void findTop3ByLikeColor테스트() {
        String findColor = "Pink";
        usersRepository.findTop3ByLikeColor(findColor).forEach(users -> System.out.println(users));
    }
    @Test
    void findByGenderAndLikeColor테스트() {
        String findColor = "Pink";
        usersRepository.findByGenderAndLikeColor(Gender.Male,findColor).forEach(users -> System.out.println(users));
    }
    @Test
    void findByCreatedAtAfter테스트() {
        usersRepository.findByCreatedAtAfter(LocalDateTime.now().minusDays(10L)).forEach(users -> System.out.println(users));
    }
    @Test
    void findByLikeColorIn테스트() {
        usersRepository.findByLikeColorIn(Lists.newArrayList("Pink" , "Blue")).forEach(users -> System.out.println(users));
    }
    @Test
    void stringSearch테스트() {
        usersRepository.findByNameStartingWith("D").forEach(users -> System.out.println("D로 시작" + users));
        usersRepository.findByNameEndingWith("S").forEach(users -> System.out.println("s로 끝" + users));
        usersRepository.findByNameContains("K").forEach(users -> System.out.println("k 포함" + users));
        usersRepository.findByNameLike("K").forEach(users -> System.out.println("k 포함" + users));
    }
    @Test
    void findByColorAndSort() {
        usersRepository.findByLikeColor("Orange",
              Sort.by(Sort.Order.asc("gender"),
              Sort.Order.desc("createdAt")))
              .forEach(users -> System.out.println(users));
    }
    //전체 페이징
    @Test
    void pagingTest(){
        System.out.println("페이지 = 0 , 페이지 당 리스트 수 : 5");
        usersRepository.findAll(PageRequest.of(0,5,Sort.by(Sort.Order.desc("id"))))
                .getContent().forEach(users -> System.out.println(users));
        System.out.println("페이지 = 1 , 페이지 당 리스트 수 : 5");
        usersRepository.findAll(PageRequest.of(1,5,Sort.by(Sort.Order.desc("id"))))
                .getContent().forEach(users -> System.out.println(users));
        System.out.println("페이지 = 2 , 페이지 당 리스트 수 : 5");
        usersRepository.findAll(PageRequest.of(2,5,Sort.by(Sort.Order.desc("id"))))
                .getContent().forEach(users -> System.out.println(users));
    }

    @Test
    void pagingTest2() {
        Pageable pageable = PageRequest.of(4, 10);
        Page<Users> result = usersRepository.findByIdGreaterThanEqualOrderByIdDesc(200L, pageable);
        result.getContent().forEach(users -> System.out.println(users));

        // 총 페이지 수
        System.out.println("Total Pages : " + result.getTotalPages());
        // 전체 데이터 개수
        System.out.println("Total Contents Count : " + result.getTotalElements());
        // 현재 페이지 번호
        System.out.println("Current Page Number : " + result.getNumber());
        // 다음 페이지 존재 여부
        System.out.println("Next Page?" + result.hasNext());
        // 시작 페이지인지 확인
        System.out.println("Is First Page?" + result.isFirst());
    }
    @Test
    void findByCreatedAtBetween테스트() {
        usersRepository.findByCreatedAtBetween(LocalDateTime.now().minusDays(31L),LocalDateTime.now())
                .forEach(users -> System.out.println(users));
        usersRepository.findByIdBetween(1L,5L).forEach(users -> System.out.println(users));
    }


    @Test void findBy테스트1번() {
        usersRepository.findByGenderAndNameLikeOrGenderAndNameLike(Gender.Female, "%m%", Gender.Female, "%w%")
                .forEach(users -> System.out.println(users));
    }
    @Test void findBy테스트2번() {
        List<Users> result = usersRepository.findByEmailLike("%net%");
        System.out.println("net 포함 수 : " + result.size());
    }
    @Test void findBy테스트3번() {
        usersRepository.findByCreatedAtBetweenAndNameStartingWith(LocalDateTime.now().minusMonths(1L), LocalDateTime.now(), "J")
                .forEach(users -> System.out.println(users));
    }
    @Test void findBy테스트4번() {
        List<Users> users =  usersRepository.findTop10ByOrderByCreatedAtDesc();

        users.forEach(user -> {
            Long id = user.getId();
            String name = user.getName();
            Gender gender = user.getGender();
            LocalDateTime createdAt = user.getCreatedAt();

            System.out.println("ID: " + id + ", Name: " + name + ", Gender: " + gender + ", Created At: " + createdAt);
        });
    }
    @Test void findBy테스트5번() {
        List<Users> users1 = usersRepository.findByGenderAndLikeColor(Gender.Male,"Red");

        users1.forEach(user -> {
            String name = user.getName();
            Gender gender = user.getGender();
            String color = user.getLikeColor();
            String email = user.getEmail();

            if (email != null && email.contains("@")) {  // '@' 기호가 있는지 확인
                String mail = email.split("@")[0];  // '@' 앞부분 추출
                System.out.println("name: " + name + ", gender: " + gender + ", color: " + color + ", Email: " + mail);
            }
        });
    }
    @Test void findBy테스트6번() {
        List<Users> users = usersRepository.findAll();

        // 갱신일이 생성일보다 먼저인 데이터를 필터링하고 출력
        List<Users> usersList = users.stream()  // 스트림을 생성
                .filter(user -> {
                    LocalDateTime createdAt = user.getCreatedAt();  // 생성일
                    LocalDateTime updatedAt = user.getUpdatedAt();  // 갱신일

                    // 갱신일이 생성일보다 먼저인 경우만 반환
                    return updatedAt != null && createdAt != null && updatedAt.isBefore(createdAt);
                })
                .toList();  // 결과를 리스트로 수집

        // 잘못된 데이터 출력
        usersList.forEach(user -> System.out.println(user));
    }
    @Test void findBy테스트7번() {
        usersRepository.findByEmailLikeAndGenderOrderByCreatedAtDesc("%edu%", Gender.Female)
                .forEach(users -> System.out.println(users));
    }
    @Test void findBy테스트8번() {
        Sort sort = Sort.by(
                Sort.Order.asc("likeColor"),
                Sort.Order.desc("name")
        );
        usersRepository.findAll(sort).forEach(users1 -> System.out.println(users1));
    }
    @Test void findBy테스트9번() {
        System.out.println("페이지 = 0 , 페이지 당 리스트 수 : 10");
        usersRepository.findAll(PageRequest.of(0,10,Sort.by(Sort.Order.desc("createdAt"))))
                .forEach(users -> System.out.println(users));
    }
    @Test void findBy테스트10번() {
        Pageable pageable = PageRequest.of(1, 3);
        Page<Users> result = usersRepository.findByGenderOrderByIdDesc(Gender.Male, pageable);
        result.forEach(users -> System.out.println(users));
    }
    @Test void findBy테스트11번() {
        LocalDateTime startMonth = LocalDateTime.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).toLocalDate().atStartOfDay(); //자정으로 시간을 설정
        // 지난달 첫 날
        LocalDateTime endMonth = LocalDateTime.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth()).toLocalDate().atTime(23, 59, 59, 999_999_999);
        // 지난 달 마지막 날

        // 지난달 데이터 가져오기
        List<Users> users = usersRepository.findByCreatedAtBetween(startMonth, endMonth);
        users.forEach(user -> System.out.println(user));
    }
}