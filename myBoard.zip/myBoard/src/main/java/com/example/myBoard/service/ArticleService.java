package com.example.myBoard.service;

import com.example.myBoard.dto.ArticleDto;
import com.example.myBoard.entity.Article;
import com.example.myBoard.repository.ArticleRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ArticleService {
    private final ArticleRepository articleRepository;

    public ArticleService(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    public List<ArticleDto> showAll() {
        List<ArticleDto> articleDtoList = new ArrayList<>();
        return articleRepository.findAll()
                .stream()
                .map(x -> ArticleDto.fromArticleEntity(x))
                .toList();
    }
    public void insert(ArticleDto dto) {
        Article article = dto.fromArticleDto(dto);
        articleRepository.save(article);
    }

    public void delete(Long id) {
        articleRepository.deleteById(id);
    }

    public ArticleDto updateView(Long id) {
        return articleRepository.findById(id)
                .map(x -> ArticleDto.fromArticleEntity(x))
                .orElse(null);
    }

    public void update(ArticleDto dto) {
        Article article = dto.fromArticleDto(dto);
        articleRepository.save(article);
    }

    public ArticleDto findId(Long id) {
        Article article = articleRepository.findById(id).orElse(null);
        if (article == null){
            return null;
        } else {
            return ArticleDto.fromArticleEntity(articleRepository.findById(id).orElse(null));
        }
    }
}
