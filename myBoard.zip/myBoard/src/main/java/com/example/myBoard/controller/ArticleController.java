package com.example.myBoard.controller;

import com.example.myBoard.dto.ArticleDto;
import com.example.myBoard.entity.Article;
import com.example.myBoard.service.ArticleService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ArticleController {
    private final ArticleService articleService;
    public ArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }
    @GetMapping("/articles/insert")
    public String insertView(ArticleDto dto , Model model){
        model.addAttribute("dto" , dto);
        return "/articles/new";
    }
    @PostMapping("/articles/insert")
    public String insert(@ModelAttribute("dto") ArticleDto dto) {
        articleService.insert(dto);
        return "redirect:/";
    }
    @PostMapping("/articles/delete")
    public String delete(@RequestParam("delete") Long id, RedirectAttributes redirectAttributes){
        // 1. 삭제할 대상이 존재 하는지
        ArticleDto dto = articleService.findId(id);

        // 2. 대상 엔티티가 존재하면 삭제 처리 후 메시지를 전송
        if (dto != null){
            articleService.delete(id);
            redirectAttributes.addFlashAttribute("msg", "정상적으로 삭제되었습니다.");
        }
        articleService.delete(id);
        return "redirect:/";
    }
    @GetMapping("/articles/update")
    public String updateView(@RequestParam("update") Long id, Model model) {
        ArticleDto dto = articleService.updateView(id);
        model.addAttribute("dto" , dto);
        return "/articles/update";
    }
    @PostMapping("/articles/update")
    public String update(@ModelAttribute("dto") ArticleDto dto){
        articleService.update(dto);
        return "redirect:/";
    }
    @GetMapping("/articles/detail/{id}")
    private String detail(@PathVariable("id")Long id, Model model){
        ArticleDto dto = articleService.findId(id);
        model.addAttribute("dto" , dto);
        return "/articles/detail";
    }
}
