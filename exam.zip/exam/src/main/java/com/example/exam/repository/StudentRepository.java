package com.example.exam.repository;

import com.example.exam.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {


    @Query (value = "SELECT SUM(kor + math + eng + hist) from exam where exam_no = :exam_no", nativeQuery = true)
    Integer sum(@Param("exam_no")  String examNo);

//    @Query(value = "select exam_no, SUM(kor + math + eng + hist) as sum from exam group by exam_no order by sum desc",
//            nativeQuery = true)




}
