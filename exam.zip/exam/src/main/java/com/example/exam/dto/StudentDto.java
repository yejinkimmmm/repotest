package com.example.exam.dto;

import com.example.exam.constant.Gender;
import com.example.exam.entity.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class StudentDto {

    private String studentNo;
    private String name;
    private String phone;
    private Gender gender;
    private String address;
    private int sum; //총합
    private ExamDto dto;


    public StudentDto(String studentNo, String name, String phone, Gender gender, String address) {
        this.studentNo = studentNo;
        this.name = name;
        this.phone = phone;
        this.gender = gender;
        this.address = address;
    }

    public StudentDto(String studentNo, String name, String phone, Gender gender, String address, int sum , ExamDto dto) {
        this.studentNo = studentNo;
        this.name = name;
        this.phone = phone;
        this.gender = gender;
        this.address = address;
        this.sum = sum;
        this.dto = dto;
    }

    public static StudentDto fromStudentEntity(Student student , ExamDto dto , int sum) {
        return new StudentDto(
                student.getStudentNo(),
                student.getName(),
                student.getPhone(),
                student.getGender(),
                student.getAddress(),
                sum,
                dto
        );
    }
    public static StudentDto fromStudent(Student student) {
        return new StudentDto(
                student.getStudentNo(),
                student.getName(),
                student.getPhone(),
                student.getGender(),
                student.getAddress()
        );
    }

    public Student fromStudentDto(StudentDto dto) {
        Student student = new Student();
        student.setStudentNo(dto.getStudentNo());
        student.setName(dto.getName());
        student.setPhone(dto.getPhone());
        student.setGender(dto.getGender());
        student.setAddress(dto.getAddress());
        return student;
    }

}
