package com.example.exam.repository;

import com.example.exam.entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ExamRepository extends JpaRepository<Exam, String> {

    @Query(value = "select sum(kor) from exam", nativeQuery = true)
    Integer korSum();
    @Query(value = "select sum(math) from exam", nativeQuery = true)
    Integer mathSum();
    @Query(value = "select sum(eng) from exam", nativeQuery = true)
    Integer engSum();
    @Query(value = "select sum(hist) from exam", nativeQuery = true)
    Integer histSum();
}
