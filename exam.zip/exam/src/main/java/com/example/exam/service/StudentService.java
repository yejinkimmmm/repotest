package com.example.exam.service;

import com.example.exam.dto.ExamDto;
import com.example.exam.dto.StudentDto;
import com.example.exam.entity.Exam;
import com.example.exam.entity.Student;
import com.example.exam.repository.ExamRepository;
import com.example.exam.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class StudentService {
    private final StudentRepository studentRepository;
    private final ExamRepository examRepository;

    public StudentService(StudentRepository studentRepository, ExamRepository examRepository) {
        this.studentRepository = studentRepository;
        this.examRepository = examRepository;
    }

    public List<StudentDto> showAll() {
        List<StudentDto> studentDtoList = new ArrayList<>();
        return studentRepository.findAll()
                .stream()
                .map(x -> StudentDto.fromStudent(x))
                .toList();
    }
    
    public List<StudentDto> examList() {
        List<Student> students = studentRepository.findAll(); //studentRepository 로 DB 안의 Student Entity 를 가져와서 students 리스트에 저장
        List<StudentDto> studentDtoList = new ArrayList<>(); //StudentDto 를 담을 ArrayList (빈 껍데기)를 studentDtoList 라는 변수로 생성

        for(Student student : students){ // Student student -> 한 줄 , students -> 전체 , 전체를 다 불러 올 때 까지 반복
            Exam exam = examRepository.findById(student.getStudentNo()).orElse(null);
            int sum = studentRepository.sum(student.getStudentNo());
            // studentNo(Id) 찾아와서 학번에 맞는 점수 가져오기 studentNo==examNo 라서 점수 가져올 수 있음
            ExamDto ex1 = ExamDto.fromExamEntity(exam); // ExamEntity 를 ExamDto 로 반환
            studentDtoList.add(StudentDto.fromStudentEntity(student,ex1,sum)); // studentDtoList 에 전체(student, exam) 다 가져오기 가능해짐
        }
        return studentDtoList; //StudentDto 를 반환해야해서 return studentDtoList 함
    }
}
