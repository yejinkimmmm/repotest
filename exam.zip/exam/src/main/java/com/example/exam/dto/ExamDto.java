package com.example.exam.dto;

import com.example.exam.entity.Exam;
import jakarta.persistence.Id;
import jakarta.validation.constraints.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ExamDto {
    @Id
    private String examNo;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer kor;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer math;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer eng;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer hist;

    private Integer korSum;
    private Integer mathSum;
    private Integer engSum;
    private Integer histSum;
    private Integer sumAll;

    public ExamDto(Integer korSum, Integer mathSum, Integer engSum, Integer histSum, Integer sumAll) {
        this.korSum = korSum;
        this.mathSum = mathSum;
        this.engSum = engSum;
        this.histSum = histSum;
        this.sumAll = sumAll;
    }
    public static ExamDto fromSubject(Integer korSum, Integer mathSum, Integer engSum, Integer histSum, Integer sumAll) {
        return new ExamDto(
                korSum,
                mathSum,
                engSum,
                histSum,
                sumAll
        );
    }

    public ExamDto(String examNo, Integer kor, Integer math, Integer eng, Integer hist) {
        this.examNo = examNo;
        this.kor = kor;
        this.math = math;
        this.eng = eng;
        this.hist = hist;
    }

    public static ExamDto fromExamEntity(Exam exam) {
        return new ExamDto(
                exam.getExamNo(),
                exam.getKor(),
                exam.getMath(),
                exam.getEng(),
                exam.getHist()
        );
    }

    public Exam fromExamDto(ExamDto dto) {
        Exam exam = new Exam();
        exam.setExamNo(dto.getExamNo());
        exam.setKor(dto.getKor());
        exam.setMath(dto.getMath());
        exam.setEng(dto.getEng());
        exam.setHist(dto.getHist());
        return exam;
    }

}
