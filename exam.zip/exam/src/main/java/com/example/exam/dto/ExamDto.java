package com.example.exam.dto;

import com.example.exam.entity.Exam;
import jakarta.persistence.Id;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExamDto {
    @Id
    private String examNo;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer kor;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer math;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer eng;

    @NotNull(message = "점수를 입력해주세요")
    @Min(value = 0, message = "점수는 0 이상이어야 합니다")
    @Max(value = 100, message = "점수는 100 이하여야 합니다")
    private Integer hist;

    public static ExamDto fromExamEntity(Exam exam) {
        return new ExamDto(
                exam.getExamNo(),
                exam.getKor(),
                exam.getMath(),
                exam.getEng(),
                exam.getHist()
        );
    }

    public Exam fromExamDto(ExamDto dto) {
        Exam exam = new Exam();
        exam.setExamNo(dto.getExamNo());
        exam.setKor(dto.getKor());
        exam.setMath(dto.getMath());
        exam.setEng(dto.getEng());
        exam.setHist(dto.getHist());
        return exam;
    }

}
