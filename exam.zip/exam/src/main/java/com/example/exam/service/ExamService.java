package com.example.exam.service;

import com.example.exam.dto.ExamDto;
import com.example.exam.entity.Exam;
import com.example.exam.repository.ExamRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ExamService {
    private final ExamRepository examRepository;

    public ExamService(ExamRepository examRepository) {
        this.examRepository = examRepository;
    }

    public void insert(ExamDto dto) {
        Exam exam = dto.fromExamDto(dto);
        examRepository.save(exam);
    }

    public List<ExamDto> subject() {
        List<Exam> exams = examRepository.findAll();
        List<ExamDto> examDtoList = new ArrayList<>();

        Integer korSum = examRepository.korSum();
        Integer mathSum = examRepository.mathSum();
        Integer engSum = examRepository.engSum();
        Integer histSum = examRepository.histSum();
        Integer sumAll = korSum + mathSum + engSum + histSum;

        examDtoList.add(ExamDto.fromSubject(korSum,mathSum,engSum,histSum,sumAll));

        return examDtoList;
    }
}
