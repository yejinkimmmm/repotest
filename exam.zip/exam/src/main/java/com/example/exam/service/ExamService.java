package com.example.exam.service;

import com.example.exam.dto.ExamDto;
import com.example.exam.entity.Exam;
import com.example.exam.repository.ExamRepository;
import org.springframework.stereotype.Service;

@Service
public class ExamService {
    private final ExamRepository examRepository;

    public ExamService(ExamRepository examRepository) {
        this.examRepository = examRepository;
    }

    public void insert(ExamDto dto) {
        Exam exam = dto.fromExamDto(dto);
        examRepository.save(exam);
    }
}
