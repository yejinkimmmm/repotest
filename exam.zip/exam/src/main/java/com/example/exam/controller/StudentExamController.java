package com.example.exam.controller;

import com.example.exam.dto.ExamDto;
import com.example.exam.dto.StudentDto;
import com.example.exam.entity.Exam;
import com.example.exam.repository.StudentRepository;
import com.example.exam.service.ExamService;
import com.example.exam.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class StudentExamController {
    private final StudentService studentService;
    private final ExamService examService;
    private final StudentRepository studentRepository;

    public StudentExamController(StudentService studentService, ExamService examService, StudentRepository studentRepository) {
        this.studentService = studentService;
        this.examService = examService;
        this.studentRepository = studentRepository;
    }

    @GetMapping("/")
    public String mainView() {
        return "/main/main";
    }

    @GetMapping("/main/student_all")
    public String studentAll(Model model){
        List<StudentDto> studentDtoList = studentService.showAll();
        model.addAttribute("dto", studentDtoList);
        return "/main/student_all";
    }
    @GetMapping("/main/score")
    public String scoreView(Model model){
        ExamDto examDto = new ExamDto();
        model.addAttribute("dto", examDto);
        return "/main/score";
    }

    @PostMapping("/main/score")
    public String submitScore(@Valid @ModelAttribute("dto") ExamDto dto, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "/main/score";
        }
        examService.insert(dto);
        return "/main/exam_list";
    }
    @GetMapping("/main/exam_list")
    public String examList(Model model){
        List<StudentDto> studentDtoList = studentService.examList();
        model.addAttribute("dto", studentDtoList);
        return "/main/exam_list";
    }
}
