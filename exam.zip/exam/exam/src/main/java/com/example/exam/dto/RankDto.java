package com.example.exam.dto;


import lombok.Data;

@Data
public class RankDto {
    private String examNo;
    private int rank;

}
