package com.example.exam.constant;

public enum Gender {
    Male,
    Female
}
