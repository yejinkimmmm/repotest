package com.example.exam.dto;

import com.example.exam.entity.Exam;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExamDto {
    private String examNo;
    private int kor;
    private int math;
    private int eng;
    private int hist;

    public static ExamDto fromExamEntity(Exam exam) {
        return new ExamDto(
                exam.getExamNo(),
                exam.getKor(),
                exam.getMath(),
                exam.getEng(),
                exam.getHist()
        );
    }

    public Exam fromExamDto(ExamDto dto) {
        Exam exam = new Exam();
        exam.setExamNo(dto.getExamNo());
        exam.setKor(dto.getKor());
        exam.setMath(dto.getMath());
        exam.setEng(dto.getEng());
        exam.setHist(dto.getHist());
        return exam;
    }

}
