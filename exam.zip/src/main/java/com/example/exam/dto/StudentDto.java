package com.example.exam.dto;

import com.example.exam.constant.Gender;
import com.example.exam.entity.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentDto {

    private String studentNo;
    private String name;
    private String phone;
    private Gender gender;
    private String address;
    private ExamDto dto;

    public StudentDto(String studentNo, String name, String phone, Gender gender, String address) {
        this.studentNo = studentNo;
        this.name = name;
        this.phone = phone;
        this.gender = gender;
        this.address = address;
    }

    public static StudentDto fromStudentEntity(Student student) {
        return new StudentDto(
                student.getStudentNo(),
                student.getName(),
                student.getPhone(),
                student.getGender(),
                student.getAddress()
        );
    }

    public Student fromStudentDto(StudentDto dto) {
        Student student = new Student();
        student.setStudentNo(dto.getStudentNo());
        student.setName(dto.getName());
        student.setPhone(dto.getPhone());
        student.setGender(dto.getGender());
        student.setAddress(dto.getAddress());
        return student;
    }

}
