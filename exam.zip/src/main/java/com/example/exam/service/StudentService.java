package com.example.exam.service;

import com.example.exam.dto.ExamDto;
import com.example.exam.dto.StudentDto;
import com.example.exam.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class StudentService {
    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public List<StudentDto> showAll() {
        List<StudentDto> studentDtoList = new ArrayList<>();
        return studentRepository.findAll()
                .stream()
                .map(x -> StudentDto.fromStudentEntity(x))
                .toList();
    }
}
