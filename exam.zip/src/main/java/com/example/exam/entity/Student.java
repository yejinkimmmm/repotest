package com.example.exam.entity;

import com.example.exam.constant.Gender;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Student {

    @Id
    @Column(name = "student_no")
    private String studentNo;
    private String name;
    private String phone;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    private String address;

}
