package com.example.exam.controller;

import com.example.exam.dto.ExamDto;
import com.example.exam.dto.StudentDto;
import com.example.exam.entity.Exam;
import com.example.exam.service.ExamService;
import com.example.exam.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class StudentExamController {
    private final StudentService studentService;
    private final ExamService examService;

    public StudentExamController(StudentService studentService, ExamService examService) {
        this.studentService = studentService;
        this.examService = examService;
    }

    @GetMapping("/")
    public String mainView() {
        return "/main/main";
    }

    @GetMapping("/main/student_all")
    public String studentAll(Model model){
        List<StudentDto> studentDtoList = studentService.showAll();
        model.addAttribute("dto", studentDtoList);
        return "/main/student_all";
    }
    @GetMapping("/main/score")
    public String scoreView(Exam examNo, Model model){
        model.addAttribute("dto", examNo);
        return "/main/score";
    }

    @PostMapping("/main/score")
    public String update(@ModelAttribute("dto") ExamDto dto){
        examService.update(dto);
        return "redirect:/";
    }
}
