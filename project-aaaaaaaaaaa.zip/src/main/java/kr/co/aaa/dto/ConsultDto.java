package kr.co.aaa.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
public class ConsultDto {
	
	private int CUST_SN; //고객 일련번호
	private String CUST_NM; // 고객 이름
	private String EML_ADDR; // 이메일주소
	private String BRDT; // 생년월일
	private String HOME_TELNO; // 자택전화번호
	private String MBL_TELNO; // 휴대전화번호
	private String PRIDTF_NO; // 개인식별번호 (주민번호)
	private String CR_NM; // 직업명
	private String ROAD_NM_ADDR; // 도로명 주소
	private String PIC_SN_VL; // 담당자 일련번호
	private String TKCG_DEPT_NM; // 담당 부서명
	private String FRST_REG_DT; // 최초 등록일
	private int FRST_RGTR_SN; // 최초 등록자 일련번호
	private String LAST_MDFCN_DT; // 마지막 수정일
	private String USE_YN; // 사용 여부 (삭제 회원인지(Y) 아닌지(N))

}
