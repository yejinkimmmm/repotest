package kr.co.aaa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sun.org.apache.regexp.internal.recompile;

import kr.co.aaa.dto.ConsultDto;
import kr.co.aaa.mapper.ConsultMapper;

@Service
public class ConsultService {

	@Autowired
	ConsultMapper mapper;
	
	public List<ConsultDto> getCustView() {
		return mapper.getCustView();
	}

}
