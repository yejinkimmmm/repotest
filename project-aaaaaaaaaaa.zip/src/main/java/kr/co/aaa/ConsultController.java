package kr.co.aaa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import kr.co.aaa.dto.ConsultDto;
import kr.co.aaa.service.ConsultService;

@Controller
public class ConsultController {
	
	@Autowired
	ConsultService consultService;
	
	@GetMapping("/custView") 
	public String custView(Model model) {
		List<ConsultDto> consultDtos = consultService.getCustView();
		model.addAttribute("consultDtos",consultDtos);
		return "/cust-view";
	}
}
