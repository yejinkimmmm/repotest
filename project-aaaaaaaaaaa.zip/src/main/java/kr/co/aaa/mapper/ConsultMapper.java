package kr.co.aaa.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.co.aaa.dto.ConsultDto;

@Mapper
public interface ConsultMapper {

	List<ConsultDto> getCustView();

}
