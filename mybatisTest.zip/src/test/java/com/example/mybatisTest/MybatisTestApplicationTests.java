package com.example.mybatisTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
