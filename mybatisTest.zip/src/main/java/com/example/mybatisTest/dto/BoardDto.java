package com.example.mybatisTest.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class BoardDto {
    private Long id;
    private String boardWriter;
    private String boardPass;
    private String boardTitle;
    private String boardContents;
    private int boardHits;
    private String createdAt;
}
