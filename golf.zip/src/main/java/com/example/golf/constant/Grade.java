package com.example.golf.constant;

public enum Grade {
    일반,
    VIP
}
