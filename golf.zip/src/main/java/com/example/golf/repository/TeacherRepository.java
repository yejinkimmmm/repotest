package com.example.golf.repository;

import com.example.golf.entity.Teacher;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, String> {
    @Query(value = "select t.class_name from class as c inner join teacher as t on c.teacher_code = t.teacher_code where c.teacher_code = :teacher_code limit 1", nativeQuery = true)
    String join(@Param("teacher_code") String teacherCode);

    @Query(value = "select sum(c.tuition) from class as c inner join teacher as t on c.teacher_code = t.teacher_code where t.teacher_code = :teacher_code group by t.teacher_code", nativeQuery = true)
    Integer total(@Param("teacher_code") String teacherCode);

//    @Query(value = "select t.teacher_code from class as c inner join teacher as t on c.teacher_code = t.teacher_code group by t.teacher_code", nativeQuery = true)
//    List<Integer> code();
//    @Query(value = "select t.class_name from class as c inner join teacher as t on c.teacher_code = t.teacher_code group by t.teacher_code", nativeQuery = true)
//    List<String> cName();
//    @Query(value = "select t.teacher_name from class as c inner join teacher as t on c.teacher_code = t.teacher_code group by t.teacher_code", nativeQuery = true)
//    List<String> tName();
//    @Query(value = "select sum(c.tuition) from class as c inner join teacher as t on c.teacher_code = t.teacher_code group by t.teacher_code", nativeQuery = true)
//    List<Integer> total();
}
