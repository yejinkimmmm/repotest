package com.example.golf.entity;

import com.example.golf.constant.Grade;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Member {

    @Id
    @Column(name = "member_id")
    public String memberId;

    @Column(name = "member_name")
    public String memberName;

    public String phone;
    public String address;
    @Enumerated(EnumType.STRING)
    public Grade grade;
}
