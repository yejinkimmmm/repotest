package com.example.golf.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Class {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "class_id")
    private Long classId;

    @Column(name = "register_month")
    private String registerMonth;

    @Column(name = "class_no")
    private String classNo;

    @Column(name = "class_area")
    private String classArea;

    private int tuition;

    @Column(name = "teacher_code")
    private String teacherCode;

}
