package com.example.golf.service;

import com.example.golf.dto.ClassDto;
import com.example.golf.dto.MemberDto;
import com.example.golf.dto.TeacherDto;
import com.example.golf.entity.Class;
import com.example.golf.entity.Member;
import com.example.golf.entity.Teacher;
import com.example.golf.repository.ClassRepository;
import com.example.golf.repository.MemberRepository;
import com.example.golf.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class ClassService {
    private final ClassRepository classRepository;
    private final MemberRepository memberRepository;
    private final TeacherRepository teacherRepository;

    public ClassService(ClassRepository classRepository, MemberRepository memberRepository, TeacherRepository teacherRepository) {
        this.classRepository = classRepository;
        this.memberRepository = memberRepository;
        this.teacherRepository = teacherRepository;
    }

    public List<TeacherDto> teacherAll() {
        List<TeacherDto> teacherDtoList = new ArrayList<>();
        return teacherRepository.findAll()
                .stream()
                .map(x -> TeacherDto.fromTeacherEntity(x))
                .toList();

    }
    public List<ClassDto> memberAll() {
        List<Class> classes = classRepository.findAll();
        List<ClassDto> classDtoList = new ArrayList<>();

        for (Class c : classes) {
            Member member = memberRepository.findById(c.getClassNo()).orElse(null);
            String join = teacherRepository.join(c.getTeacherCode());
            MemberDto memberDto = MemberDto.fromMemberEntity(member);
            classDtoList.add(ClassDto.fromClassEntityMember(c, memberDto , join));
        }
        return classDtoList;
    }

    public List<ClassDto> totalTuition() {
        List<Class> classes = classRepository.findAll();
        List<ClassDto> classDto = new ArrayList<>();

        Set<String> seenTeacherCodes = new HashSet<>(); // 변수 선언과 초기화

        for (Class cl : classes) {

            if (!seenTeacherCodes.add(cl.getTeacherCode())) {
                continue; // 중복된 경우, 처리하지 않고 건너뛰기
            }

            Teacher teacher = teacherRepository.findById(cl.getTeacherCode()).orElse(null);
            Integer total = teacherRepository.total(cl.getTeacherCode());
            TeacherDto teacherDto = TeacherDto.fromTeacherEntity(teacher);
            classDto.add(ClassDto.fromTotal(cl, teacherDto, total));
        }
        return classDto;
    }

    public List<MemberDto> insertMember() {
        List<MemberDto> memberDtoList = new ArrayList<>();
        return memberRepository.findAll()
                .stream()
                .map(x -> MemberDto.fromMemberEntity(x))
                .toList();
    }

    public void insert(ClassDto dto) {
        Class classes = dto.fromClassDto(dto);
        classRepository.save(classes);
    }
}


