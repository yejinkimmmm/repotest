package com.example.golf.service;

import org.springframework.stereotype.Service;

@Service
public class GolfService {
}
