package com.example.golf.dto;

import com.example.golf.constant.Grade;
import com.example.golf.entity.Member;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberDto {

    public String memberId;
    public String memberName;
    public String phone;
    public String address;
    public Grade grade;

    // Entity 를 DTO 로 변환
    public static MemberDto fromMemberEntity(Member member) {
        return new MemberDto(
                member.getMemberId(),
                member.getMemberName(),
                member.getPhone(),
                member.getAddress(),
                member.getGrade()
        );
    }
}
