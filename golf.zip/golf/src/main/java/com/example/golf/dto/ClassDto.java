package com.example.golf.dto;

import com.example.golf.entity.Class;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ClassDto {

    private Long classId;
    private String registerMonth;
    private String classNo;
    private String classArea;
    private int tuition;
    private String teacherCode;
    private MemberDto memberDto;
    private TeacherDto teacherDto;
    private String join;
    private String formatMonth;
    private String formatTuition;
    private Integer code;
    private String cName;
    private String tName;
    private Integer total;
    private String formatTotal;

    public ClassDto(Long classId, String registerMonth, String classNo, String classArea, int tuition, String teacherCode, MemberDto memberDto, String join) {
        this.classId = classId;
        this.registerMonth = registerMonth;
        this.classNo = classNo;
        this.classArea = classArea;
        this.tuition = tuition;
        this.teacherCode = teacherCode;
        this.memberDto = memberDto;
        this.join = join;
    }
    // Entity 를 DTO 로 변환
    public static ClassDto fromClassEntityMember(Class c , MemberDto memberDto, String join){
        return new ClassDto(
                c.getClassId(),
                c.getRegisterMonth(),
                c.getClassNo(),
                c.getClassArea(),
                c.getTuition(),
                c.getTeacherCode(),
                memberDto,
                join
        );
    }

    public ClassDto(int tuition ,TeacherDto teacherDto, Integer total) {
        this.tuition = tuition;
        this.teacherDto = teacherDto;
        this.total = total;
    }
    public static ClassDto fromTotal(Class c, TeacherDto teacherDto, Integer total){
        return new ClassDto(
                c.getTuition(),
                teacherDto,
                total
        );
    }

//    public ClassDto(Integer code, String cName, String tName, Integer total) {
//        this.code = code;
//        this.cName = cName;
//        this.tName = tName;
//        this.total = total;
//    }
//    public static ClassDto fromTotal(Integer code, String cName, String tName, Integer total) {
//        return new ClassDto(code, cName, tName, total);
//    }

    public void setFormatTuition(String formatTuition) {
        this.formatTuition = formatTuition;
    }
    public void setFormatMonth(String formatMonth) {
        this.formatMonth = formatMonth;
    }
    public void setFormatTotal(String formatTotal) {
        this.formatTotal= formatTotal;
    }


}
