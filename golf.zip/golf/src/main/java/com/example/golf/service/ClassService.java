package com.example.golf.service;

import com.example.golf.dto.ClassDto;
import com.example.golf.dto.MemberDto;
import com.example.golf.dto.TeacherDto;
import com.example.golf.entity.Class;
import com.example.golf.entity.Member;
import com.example.golf.entity.Teacher;
import com.example.golf.repository.ClassRepository;
import com.example.golf.repository.MemberRepository;
import com.example.golf.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ClassService {
    private final ClassRepository classRepository;
    private final MemberRepository memberRepository;
    private final TeacherRepository teacherRepository;

    public ClassService(ClassRepository classRepository, MemberRepository memberRepository, TeacherRepository teacherRepository) {
        this.classRepository = classRepository;
        this.memberRepository = memberRepository;
        this.teacherRepository = teacherRepository;
    }

    public List<ClassDto> memberAll() {
        List<Class> classes = classRepository.findAll();
        List<ClassDto> classDtoList = new ArrayList<>();

        for (Class c : classes) {
            Member member = memberRepository.findById(c.getClassNo()).orElse(null);
            String join = teacherRepository.join(c.getTeacherCode());
            MemberDto memberDto = MemberDto.fromMemberEntity(member);
            classDtoList.add(ClassDto.fromClassEntityMember(c, memberDto , join));
        }
        return classDtoList;
    }

    public List<ClassDto> totalTuition() {
        List<Class> classes = classRepository.findAll();
        List<ClassDto> classDto = new ArrayList<>();

        for (Class cl : classes) {
            Teacher teacher = teacherRepository.findById(cl.getTeacherCode()).orElse(null);
            Integer total = teacherRepository.total(cl.getTeacherCode());
            TeacherDto teacherDto = TeacherDto.fromTeacherEntity(teacher);
            classDto.add(ClassDto.fromTotal(cl, teacherDto, total));
        }
        return classDto;
    }
}


