package com.example.golf.service;

import com.example.golf.dto.ClassDto;
import com.example.golf.dto.MemberDto;
import com.example.golf.dto.TeacherDto;
import com.example.golf.entity.Class;
import com.example.golf.entity.Member;
import com.example.golf.entity.Teacher;
import com.example.golf.repository.ClassRepository;
import com.example.golf.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TeacherService {
    private final TeacherRepository teacherRepository;
    private final ClassRepository classRepository;

    public TeacherService(TeacherRepository teacherRepository, ClassRepository classRepository) {
        this.teacherRepository = teacherRepository;
        this.classRepository = classRepository;
    }

    public List<TeacherDto> teacherAll() {
        List<TeacherDto> teacherDtoList = new ArrayList<>();
        return teacherRepository.findAll()
                .stream()
                .map(x -> TeacherDto.fromTeacherEntity(x))
                .toList();

    }
}
