package com.example.golf.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Teacher {

    @Id
    @Column(name = "teacher_code")
    public String teacherCode;

    @Column(name = "teacher_name")
    public String teacherName;

    @Column(name = "class_name")
    public String className;

    public int price;

    @Column(name = "teacher_register_date")
    public String teacherRegisterDate;
}
