package com.example.golf.controller;

import com.example.golf.dto.ClassDto;
import com.example.golf.dto.TeacherDto;
import com.example.golf.entity.Class;
import com.example.golf.service.ClassService;
import com.example.golf.service.MemberService;
import com.example.golf.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class GolfController {

    private final ClassService classService;
    private final TeacherService teacherService;
    private final MemberService memberService;

    public GolfController(ClassService classService, TeacherService teacherService, MemberService memberService) {
        this.classService = classService;
        this.teacherService = teacherService;
        this.memberService = memberService;
    }

    @GetMapping("/")
    public String mainPage(){
        return "main/main";
    }

    @GetMapping("/main/teacher")
    public String teacherAll(Model model) throws ParseException {
        DecimalFormat decimalFormat = new DecimalFormat("₩###,###");
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy년MM월dd일");
        // 날짜 입력 형식을 확인
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyyMMdd");

        List<TeacherDto> teacherDtoList = teacherService.teacherAll();

        for (TeacherDto teacher : teacherDtoList) {
            // 수강료 포맷팅
            String formatPrice = decimalFormat.format(teacher.getPrice());
            teacher.setFormatPrice(formatPrice);

            // 날짜 포맷팅
            Date registerDate = inputDateFormat.parse(teacher.getTeacherRegisterDate());
            String formattedDate = outputDateFormat.format(registerDate);
            teacher.setFormatDate(formattedDate);
        }

        model.addAttribute("teacherList", teacherDtoList);
        return "main/teacher";
    }

    @GetMapping("/main/member")
    public String memberDtoList(Model model) throws ParseException {
        DecimalFormat decimalFormat = new DecimalFormat("₩###,###");
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy년MM월");
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyyMM");

        List<ClassDto> classDtoList = classService.memberAll();
        for (ClassDto c : classDtoList) {
            // 수강료 포맷팅
            String formatTuition = decimalFormat.format(c.getTuition());
            c.setFormatTuition(formatTuition);

            // 날짜 포맷팅
            Date registerMonth = inputDateFormat.parse(c.getRegisterMonth());
            String formatMonth = outputDateFormat.format(registerMonth);
            c.setFormatMonth(formatMonth);
        }

        model.addAttribute("classDto", classDtoList);
        return "/main/member";
    }

    @GetMapping("/main/sales")
    public String sales(Model model) {
        DecimalFormat decimalFormat = new DecimalFormat("₩###,###");
        List<ClassDto> classDto = classService.totalTuition();
        for (ClassDto cl : classDto) {
            String formatTotal = decimalFormat.format(cl.getTotal());
            cl.setFormatTotal(formatTotal);
        }
        model.addAttribute("sales" , classDto);
        return "/main/sales";
    }
}
