package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.Member;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.thymeleaf.expression.Arrays;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/member")
public class MemberController {
    @GetMapping("/member")
    public String member(Model model) {
        addMember(model);
        return "member/member";
    }

    @GetMapping("/block")
    public String block (Model model) {
        addMember(model);
        return "block";
    }

    private void addMember(Model model) {
        List<Member> memberList = new ArrayList<>();

        for (int i=1; i<=15; i++){
            if(i<10){
                memberList.add(
                        new Member("name_0" + i,
                                "addr_0" + i));
            } else {
                memberList.add(
                        new Member("name_" + i,
                                "addr_" + i));
            }
        }

        LocalDateTime localDateTime = LocalDateTime.now();

        model.addAttribute("member", memberList);
        model.addAttribute("localDateTime", localDateTime);
    }
}
