package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.Gender;
import com.example.thymeleafTest.vo.InputDto;
import com.example.thymeleafTest.vo.Mail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@Slf4j
public class formControlController {
    @GetMapping ("/signUpView")
    public String showSign(Model model){
        model.addAttribute("dto", new InputDto());
        return "sign/signUpView";
    }
    @PostMapping("/signUpView")
    public String postSign(@ModelAttribute("dto") InputDto dto, Model model){
        log.info("ID : " + dto.getId());
        log.info("PW : " + dto.getPw());
        log.info("PW Check : " + dto.getPw2());
        log.info("NAME : " + dto.getName());
        log.info("BIRTH : " + dto.getBirth());
        log.info("GENDER : " + dto.getGender());
        List<String> agree = dto.getAgree();
        for (String a : agree) {
            log.info("AGREE : " + a);
        }
        log.info("E-MAIL : " + dto.getMail());
        log.info("PHONE : " + dto.getPhone());
        return "sign/signUpView";
    }
    @ModelAttribute("gender")
    private Gender[] genders(){
        return Gender.values();
    }
    @ModelAttribute("mail")
    private Mail[] mail(){
        return Mail.values();
    }

    @ModelAttribute("agree")
    private Map<String,String> agree(){
        Map<String, String> map = new HashMap<>();
        map.put("agree", "이용약관 동의(필수)");
        map.put("agree2", "개인정보 수집,이용 동의(필수)");
        map.put("agree3", "개인정보 수집,이용 동의(선택)");
        return map;
    }
}
