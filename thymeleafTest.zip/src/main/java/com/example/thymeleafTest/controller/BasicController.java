package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.Users;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDateTime;
import java.util.*;

@Controller  // 필수
@RequestMapping("/basic") // Request : 받는 거  /basic 를 거치라는 뜻 GetMapping 에 있는 애들 다 내 거야~

public class BasicController {
    @GetMapping("/text-basic")
    public String textBasic(Model model){
        model.addAttribute("data", "Hello <b>Spring!</b>");
        return "/basic/text-basic";  // basic 밑에 있는 text-basic
    }

    @GetMapping("/variable")
    public String variable(Model model){
        Users userA = new Users("손흥민",31);
        Users userB = new Users("조규성",26);
        List<Users> list = new ArrayList<>(Arrays.asList(userA, userB));

        Map<String, Users> map = new HashMap<>();
        map.put("son", userA);
        map.put("cho", userB);

        model.addAttribute("userSon", userA); // 손흥민 클래스를 유저에 보냄
        model.addAttribute("userList", list);
        model.addAttribute("userMap", map);

        return "basic/variable";
    }
    @GetMapping("/date")
    public String date(Model model){
        model.addAttribute("localTime", LocalDateTime.now());
        return "date";
    }
    @GetMapping("/literal")
    public String literal(Model model) {
        model.addAttribute("data" ,"Spring!!!");
        model.addAttribute("nullData", null);
        model.addAttribute("name", "손흥민");
        return "literal";
    }

    @GetMapping("/each")
    public String each(Model model) {
        addUsers(model);
        return "each";
    }

    private void addUsers(Model model) {
        List<Users> userList = new ArrayList<>(
                Arrays.asList(
                        new Users("안유진" ,22),
                        new Users("장원영" ,21),
                        new Users("이서" ,18),
                        new Users("가을" ,23),
                        new Users("리즈" ,21),
                        new Users("레이" ,21)
                )
        );
        model.addAttribute("users", userList);
    }
}
