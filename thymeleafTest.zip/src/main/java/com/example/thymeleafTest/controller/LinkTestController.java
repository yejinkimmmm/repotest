package com.example.thymeleafTest.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
//@RequestMapping ("/articles") // 이거 써도 됨 쓰면 /articles 안 쓰고 그녕 /list 씀
public class LinkTestController {

    @GetMapping("/main")
    public String main(Model model){
        model.addAttribute("name","tom");
        model.addAttribute("height",180);
        model.addAttribute("weight",80);

        return "/articles/main";
    }
    @GetMapping("/articles/list")
    public String list_all(Model model){
        String title = "/articles/list";
        String message ="전체 게시글 읽기 성공";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);
        return "/articles/list_all";
    }

    @GetMapping("/articles/member/{id}")
    public String memberSelect(Model model,
                               @PathVariable("id") int id,
                               @RequestParam("name") String name){
        String title = "/articles/member/{id}";
        String message = name + "이 선택되었습니다";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);
        return "/articles/member_list";
    }

    @GetMapping("/articles/{id}")
    public String id(@PathVariable("id") int id, Model model){
        String title = "/articles/{id}";
        String message = id + "번 게시글 읽기 성공";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);
        return "/articles/list_one";
    }

    @GetMapping("/articles/create")
    public String create(@RequestParam ("name") String name,
                         @RequestParam ("height") int height,
                         @RequestParam ("weight") int weight,
                         Model model){
//        String title = "/articles/create?name=" + name + "&height=" + height + "&weight=" + weight;
//        String message = name + "의 키는 " + height + "몸무게는 " + weight + "입니다." ;
//
//        model.addAttribute("title" , title);
//        model.addAttribute("message", message);
        model.addAttribute("name", name);
        model.addAttribute("height", height);
        model.addAttribute("weight", weight);

        return "articles/new";
    }
    @GetMapping("/articles/update")
    public String update(Model model){
        String title = "/articles/update";
        String message ="업데이트 성공";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);
        return "/articles/update_ok";
    }

    @GetMapping("/articles/{id}/update")
    public String idUpdate(@PathVariable("id") int id,
                           Model model){
        String title = "/articles/{id}/update";
        String message = id + "번 게시글 수정 폼 로딩 완료";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);
        return "/articles/update";
    }
    @GetMapping("/articles/{id}/delete")
    public String delete(@PathVariable("id") int id,
                         Model model){

        String title = "/articles/{id}/delete";
        String message = id + "번 글 삭제 완료";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);
        return "/articles/delete_ok";
    }
    @GetMapping("/articles/{id}/articleComment")
    public String comment(@PathVariable("id") int id,
                          Model model){
        String title = "/articles/{id}/articleComment";
        String message = id + "번 게시글의 모든 댓글보기 성공";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);

        return "/articles/comment_view";
    }
    @GetMapping("/articles/{id}/articleComments/{articleCommentId}/delete")
    public String acid(@PathVariable("id") int id,
                       @PathVariable("articleCommentId") int articleCommentId,
                       Model model){

        String title = "/articles/{id}/articleComments/{articleCommentId}/delete";
        String message = id + "번 게시글의 " + articleCommentId + "번 째 답글 삭제 완료";

        model.addAttribute("title" , title);
        model.addAttribute("message", message);
        return "/articles/delete_ok";
    }

}
