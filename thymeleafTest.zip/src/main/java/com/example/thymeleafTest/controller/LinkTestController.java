package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.UserT;
import com.example.thymeleafTest.vo.Users;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller

public class LinkTestController {
    @GetMapping("/main")
    public String create (Model model){
        model.addAttribute("name","tom");
        model.addAttribute("height",180);
        model.addAttribute("weight",80);

        return "/articles/main";
    }
    @GetMapping("/articles/list")
    public String list_all(){
        return "/articles/list_all";
    }
    @GetMapping("/articles/{id}")
    public String id(@PathVariable("id") String id,
                     Model model){
        model.addAttribute("id", id);
        return "/articles/list_one";
    }

    @GetMapping("/articles/create")
    public String create(@RequestParam ("name") String name,
                         @RequestParam ("height") int height,
                         @RequestParam ("weight") int weigh,
                         Model model){
        model.addAttribute("name", name);
        model.addAttribute("height", height);
        model.addAttribute("weight", weigh);
        return "articles/new";
    }
    @GetMapping("/articles/update")
    public String update(){
        return "/articles/update_ok";
    }

    @GetMapping("/articles/{id}/update")
    public String idUpdate(@PathVariable("id") String id,
                           Model model){
        model.addAttribute("id", id);
        return "/articles/update";
    }
    @GetMapping("/articles/{id}/delete")
    public String delete(@PathVariable("id") String id,
                         Model model){
        model.addAttribute("id", id);
        model.addAttribute("deleteMessage", "a");
        return "/articles/delete_ok";
    }
    @GetMapping("/articles/{id}/articleComment")
    public String comment(@PathVariable("id") String id,
                          Model model){
        model.addAttribute("id", id);
        return "/articles/comment_view";
    }
    @GetMapping("/articles/{id}/articleComments/{article-comment-id}/delete")
    public String acid(@PathVariable("id") String id,
                       @PathVariable("article-comment-id") String articleCommentId,
                       Model model){
        model.addAttribute("id", id);
        model.addAttribute("article-comment-id", articleCommentId);
        model.addAttribute("deleteMessage", "b");
        return "/articles/delete_ok";
    }

}
