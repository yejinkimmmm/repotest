package com.example.thymeleafTest.vo;

public class OutputDto {
}
