package com.example.thymeleafTest.vo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

//lombok
//@Setter
//@Getter
//@ToString
@Data   // 위에 모든 걸 한번에 설정해줌(setter, getter, toString) 전부 다 필요한 게 아니면 굳이 쓰지 말기 (lombok)
public class FormDto {
    private String name;
    private boolean trueOrFalse;
    private List<String> hobbies; // multi-checkBox
    private String language; // radio-button
    private String country; // select
}
