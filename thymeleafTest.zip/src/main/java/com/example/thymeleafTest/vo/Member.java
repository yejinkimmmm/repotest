package com.example.thymeleafTest.vo;

public class Member {
    private String name;
    private String addr;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public Member(String name, String addr) {
        this.name = name;
        this.addr = addr;
    }
}
