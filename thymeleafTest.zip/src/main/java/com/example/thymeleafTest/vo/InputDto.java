package com.example.thymeleafTest.vo;

import lombok.Data;

import java.util.List;

@Data
public class InputDto {
    private String id;
    private String pw;
    private String pw2; // 확인용
    private String name;
    private String birth;
    private String gender;
//    private String list1;
//    private String list2;
//    private String list3;
    private List<String> agree;
    private String mail;
    private String mail2; // 도매인 주소도 출력되게 해야 함 ㅎㅐ봐라!
    private String phone;
}
