package vendingMachineTest;

public class VendingMachine {
    static int totalMoney = 0; //콜라랑 사이다에서 다 접근 가능해야해서 static main 위에 써야함
    public static void main(String[] args) {
        VMachine colaMachine = new VMachine();

        colaMachine.name = "콜라";
        colaMachine.productPrice = 600;
        colaMachine.insertMoney(1000);
        colaMachine.serveProduct();
        System.out.println("현재 수익은 : " + totalMoney);




//        ColaVendingMachine colaVendingMachine = new ColaVendingMachine();
//        CyderVendingMachine cyderVendingMachine = new CyderVendingMachine();
//
//        colaVendingMachine.insertMoney(1000);
//        colaVendingMachine.insertMoney(500);
//        colaVendingMachine.serveCola();
//        System.out.println("현재 수익은 : " + totalMoney);
//
//        cyderVendingMachine.insertMoney(1000);
//        cyderVendingMachine.serveCyder();
//        System.out.println("현재 수익은 : " + totalMoney);
//
//
//
//        System.out.println("--------------------");






    }
}
