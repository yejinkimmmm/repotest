package vendingMachineTest;

public class CyderVendingMachine {
    final String name = "사이다";
    int currentMoney = 0; // 투입 금액
    final int productPrice = 900; // 가격


    void currentMoneyPrint() {
        System.out.println("현재 잔액은" + currentMoney + "원 입니다.");
    }

    void insertMoney(int money) {
        currentMoney = currentMoney + money;
        currentMoneyPrint();
    }

    void serveCyder() {
        if (currentMoney < productPrice) {
            System.out.println("잔액이 부족합니다.");
        } else {
            System.out.println("사이다 1개를 드립니다.");
            currentMoney = currentMoney - productPrice;
            currentMoneyPrint();
            VendingMachine.totalMoney = VendingMachine.totalMoney + productPrice;
        }
    }
}
