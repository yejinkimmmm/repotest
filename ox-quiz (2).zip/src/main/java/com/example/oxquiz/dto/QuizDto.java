package com.example.oxquiz.dto;

import com.example.oxquiz.entity.Quiz;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class QuizDto {

    private Long id;

    private String content;

    @NotBlank(message = "정답 입력 필수")
    private String answer;

    @Size(min = 2, message = "이름은 2자 이상으로 입력해야 합니다.")
    private String name;

    public static QuizDto fromQuizEntity(Quiz quiz) {
        return new QuizDto(
                quiz.getId(), quiz.getContent(), quiz.getAnswer(), quiz.getName()
        );
    }
}
