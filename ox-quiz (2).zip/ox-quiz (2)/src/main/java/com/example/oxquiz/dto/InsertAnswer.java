package com.example.oxquiz.dto;

import lombok.Getter;

@Getter
public enum InsertAnswer {
    YES("O"),NO("X");
    private final String description;

    InsertAnswer(String description) {
        this.description = description;
    }
}
