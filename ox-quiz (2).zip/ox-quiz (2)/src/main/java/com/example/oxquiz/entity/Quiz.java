package com.example.oxquiz.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Quiz {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false)
    private String content;

    private String answer;

    @Column(length = 20, nullable = false)
    private String name;

}
