package com.example.oxquiz.controller;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.Quiz;
import com.example.oxquiz.repository.QuizRepository;
import com.example.oxquiz.service.QuizService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@Slf4j
@RequestMapping("quiz")

public class QuizController {
    private final QuizService quizService;
    private final QuizRepository quizRepository;

    public QuizController(QuizService quizService, QuizRepository quizRepository) {
        this.quizService = quizService;
        this.quizRepository = quizRepository;

    }


    @GetMapping("/quiz")
    public String quizAll(Model model) {
        List<QuizDto> quizDtoList = quizService.showAllQuiz();
        model.addAttribute("quizDto" , quizDtoList);
        return "showQuiz";
    }

    @GetMapping("insert")
    public String insertForm(Model model) {
        model.addAttribute("quizDto" , new QuizDto());
        return "insert";
    }

    @PostMapping("insert")
    public String insertAnswer(@ModelAttribute("quizDto") QuizDto dto) {
        log.info(dto.toString());
        // 가져온 DTO 를 Entity Member class 에 옮겨 담아용
        Quiz quiz = dto.fromQuizDto(dto);
        log.info("Quiz :" +  quiz.toString());

        // 저장합니다
       quizRepository.save(quiz);
        return "redirect:/quiz/quiz";
    }

}
